/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataFiles;

import java.io.*;
import java.text.*;
import java.util.*;
import javax.swing.JOptionPane;

public class EditBookings 
{
    
    public static String[] updatePayment(String bookingID) throws FileNotFoundException{
        String ID = bookingID;

        // modifiedlist to store all updated bookings
        ArrayList<String> modifiedList
            = new ArrayList<String>();
        
        String[] bookingDetails = CheckAllData.checkAllData("bookings.txt");
        
        //loop to get each booking from booking details arraylist
        for (String eachRoomBooking : bookingDetails) {
            String[] roomBookingData = eachRoomBooking.split("//"); //split the booking info
            
            //store booking info of that room
            if (ID.equals(roomBookingData[0]))
            {
                roomBookingData[17] = "PAID";      
            }                        
            
            StringBuilder bookingBd = new StringBuilder();
            for (int i=0; i<roomBookingData.length; i++) {
                                
                bookingBd.append(roomBookingData[i]);
                
                //last element no need seperator
                if (i == (roomBookingData.length - 1)){
                    break;
                }                 
                bookingBd.append("//");                
            }
            
            String booking = bookingBd.toString();
            
            modifiedList.add(booking);
        }
                
        // convert booking List to string array
        String[] modifiedBookings
                = modifiedList.toArray(new String[0]);
            
        return modifiedBookings;
    }    

    public static String[] updateBookings(String getId, String getContactNumber, String getEmail, String getEmergencyNumber, String getFullName, String getHomeAddress, 
            String getIc, String getStartDate, String getNumOfDays, String getEndDate, String getRoomID, String getView, String getDate, String getTime, 
            String getTotalAmount, String getServiceCharge, String getTotalRoomPrice) throws FileNotFoundException{
        String ID = getId;

        // modifiedlist to store all updated bookings
        ArrayList<String> modifiedList
            = new ArrayList<String>();
        
        String[] bookingDetails = CheckAllData.checkAllData("bookings.txt");
        
        //loop to get each booking from booking details arraylist
        for (String eachRoomBooking : bookingDetails) {
            String[] roomBookingData = eachRoomBooking.split("//"); //split the booking info
            
            //store booking info of that room
            if (ID.equals(roomBookingData[0]))
            {
                roomBookingData[1] = getFullName;
                roomBookingData[2] = getIc;
                roomBookingData[3] = getContactNumber;
                roomBookingData[4] = getEmergencyNumber;
                roomBookingData[5] = getEmail;
                roomBookingData[6] = getHomeAddress;
                roomBookingData[7] = getStartDate;
                roomBookingData[8] = getEndDate;
                roomBookingData[9] = getView;
                roomBookingData[10] = getRoomID;
                roomBookingData[11] = getNumOfDays;
                roomBookingData[12] = getDate;
                roomBookingData[13] = getTime;
                roomBookingData[14] = getServiceCharge;
                roomBookingData[15] = getTotalRoomPrice;
                roomBookingData[16] = getTotalAmount; 
            }                        
            
            StringBuilder bookingBd = new StringBuilder();
            for (int i=0; i<roomBookingData.length; i++) {
                                
                bookingBd.append(roomBookingData[i]);
                
                //last element no need seperator
                if (i == (roomBookingData.length - 1)){
                    break;
                }                 
                bookingBd.append("//");                
            }
            
            String booking = bookingBd.toString();
            
            modifiedList.add(booking);
        }
                
        // convert booking List to string array
        String[] modifiedBookings
                = modifiedList.toArray(new String[0]);
            
        return modifiedBookings;
    }     

    public static String[] DeleteBookings(String bookingID) throws FileNotFoundException{

        String ID = bookingID;

        // modifiedlist to store all updated bookings
        ArrayList<String> modifiedList
            = new ArrayList<String>();
        
        String[] bookingDetails = CheckAllData.checkAllData("bookings.txt");
        
        //loop to get each booking from booking details arraylist
        for (String eachRoomBooking : bookingDetails) {
            String[] roomBookingData = eachRoomBooking.split("//"); //split the booking info
            
            //store booking info of that room
            if (ID.equals(roomBookingData[0]))
            {
                continue;     
            }
            else                        
            {
                StringBuilder bookingBd = new StringBuilder();
                for (int i=0; i<roomBookingData.length; i++) {

                    bookingBd.append(roomBookingData[i]);

                    //last element no need seperator
                    if (i == (roomBookingData.length - 1)){
                        break;
                    }                 
                    bookingBd.append("//");                
                }

                String booking = bookingBd.toString();

                modifiedList.add(booking);
            }
        }
                
        // convert booking List to string array
        String[] modifiedBookings
                = modifiedList.toArray(new String[0]);
            
        return modifiedBookings;
    }    
    
}
