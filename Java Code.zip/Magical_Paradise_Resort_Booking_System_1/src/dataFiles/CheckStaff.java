package dataFiles;

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import model.Staff;

public class CheckStaff {
    
    public static Boolean checkExistingStaff(Staff staff) {
        Boolean usernameExist = false; //set as false
        String username = staff.getUsername();//get username

        try {            
            String[] staffDetails = CheckAllData.checkAllData("staff.txt");
            
            //create arraylist to store all username
            ArrayList<String> existingUsername
                    = new ArrayList<String>();
            
            //loop to get each staff from staffdetails arraylist
            for (String eachStaff : staffDetails) {
                String[] staffValue = eachStaff.split("//"); //split the staff info
                existingUsername.add(staffValue[1]); //add all username to arraylist
            }                

            //loop the existingUsername arraylist to check username
            for (int j = 0; j < existingUsername.size() ; j++) {
                if(username.equalsIgnoreCase(existingUsername.get(j))){
                    usernameExist = true;
                    break;
                }
            }
                                  
        }catch(IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        return usernameExist;

    }
    
    public static Boolean checkLoginCredential(Staff staff) {
        Boolean credential = false; //set as false
        String username = staff.getUsername();//get username
        String password = staff.getPassword();//get password

        try {
            String[] staffDetails = CheckAllData.checkAllData("staff.txt");
            
            //create arraylist to store all username
            ArrayList<String> existingUsername
                    = new ArrayList<String>();
            
            //create arraylist to store all password
            ArrayList<String> existingPassword
                    = new ArrayList<String>();
            
            //loop to get each staff from staffdetails arraylist
            for (String eachStaff : staffDetails) {
                String[] staffValue = eachStaff.split("//"); //split the staff info
                existingUsername.add(staffValue[1]); //add all username to arraylist
                existingPassword.add(staffValue[5]); //add all password to arraylist
            }                

            //loop the existing Username and password  arraylist to check credential
            for (int j = 0; j < existingUsername.size() ; j++) {
                if(username.equals(existingUsername.get(j)) && password.equals(existingPassword.get(j))){
                    credential = true;
                    break;
                }
            }
                                  
        }catch(IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        return credential;

    }

}
