/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataFiles;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author sophi
 */
public class DateFormatting {
    
    Date start, end, ytd;
    String sDate, eDate, yDate;
    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");  
    
    public DateFormatting(Date startDate,Date endDate, Date ytdDate){
        
        //Date type
        start = startDate;
        end = endDate;
        ytd = ytdDate;
        
        //String type  
        sDate = sdf.format(start);
        eDate = sdf.format(end);
        yDate = sdf.format(ytd);    
    }
    
    //format dates to string to eliminate seconds
    
    public String StartDateString()
    {   
        
        String startDateString = sdf.format(start);

        return startDateString;
    }     
    
    public String EndDateString()
    {   
        
        String endDateString = sdf.format(end);

        return endDateString;
    }       
    
    public String YtdDateString()
    {   
        
        String ytdDateString = sdf.format(ytd);

        return ytdDateString;
    }       

    //format string to date to do comparison
    
    public Date StartDate() throws ParseException{

        Date startDate = sdf.parse(sDate);
        
        return startDate;
    }    
    
    public Date EndDate() throws ParseException{

        Date endDate = sdf.parse(eDate);
        
        return endDate;
    }    
    
    public Date YtdDate() throws ParseException{

        Date ytdDate = sdf.parse(yDate);
        
        return ytdDate;
    }        
    
       
}
