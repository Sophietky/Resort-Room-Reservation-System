/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataFiles;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class CheckBookings 
{
    
    public static Boolean checkRoomAvailability(String roomID, String checkStartDate, String checkEndDate){
    
        Boolean available = true; //set as true

        try {

            String[] bookingDetails = CheckAllData.checkAllData("bookings.txt");

            //create booked room list to store all room info
            ArrayList<String> bookedRoomInfo
                    = new ArrayList<String>();            

            //loop to get each booking from booking details arraylist
            for (String eachRoomBooking : bookingDetails) {
                String[] roomBookingData = eachRoomBooking.split("//"); //split the booking info
                
                //store booking info of that room
                if (roomID.equals(roomBookingData[10]))
                {
                    bookedRoomInfo.add(roomBookingData[7]+"//"+roomBookingData[8]);//store date        
                }
            }

            // convert booked room list to string array
            String[] bookedRoomDetails
                = bookedRoomInfo.toArray(new String[0]);   

            //loop to get each booking from booking details arraylist
            for (String eachBooking : bookedRoomDetails) {
                String[] roomBookingDate = eachBooking.split("//"); //split the booking info

                //get previous start date and end date
                String sDate = roomBookingDate[0];
                String eDate = roomBookingDate[1];  
                
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");  
                
                //format string to date to eliminate millisecond
                //previous
                Date sd = sdf.parse(sDate);
                Date ed = sdf.parse(eDate);
                //new 
                Date cs = sdf.parse(checkStartDate);
                Date ce = sdf.parse(checkEndDate);
                
                //format date to string to eliminate millisecond
                //previous
                String startDate = sdf.format(sd);
                String endDate = sdf.format(ed);
                //new 
                String cStart = sdf.format(cs);
                String cEnd = sdf.format(ce);                
                
                //format string to date to do comparison
                //previous
                Date start = sdf.parse(startDate);
                Date end = sdf.parse(endDate);
                //new
                Date checkStart = sdf.parse(cStart);
                Date checkEnd = sdf.parse(cEnd);
                
                //check between 2 dates
                if (checkStart.after(start) && checkStart.before(end))
                {
                    available = false;
                }else
                if (checkEnd.after(start) && checkEnd.before(end))
                {
                    available = false;
                }else
                if (checkStart.equals(start) || checkStart.equals(end))
                {     
                    available = false;
                }else
                if (checkEnd.equals(end) || checkEnd.equals(start))
                {                   
                    available = false;
                }
                
            }         
        }catch(IOException e){
            JOptionPane.showMessageDialog(null, e);
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        
        return available;
        
    }    

    public static String checkBookingID() throws FileNotFoundException {
        String bookingID;

        String[] bookingDetails = CheckAllData.checkAllData("bookings.txt");            

        //create arraylist to store all booking ID
        ArrayList<String> existingID
                = new ArrayList<String>();

        //loop to get each booking from booked details arraylist
        for (String eachBooking : bookingDetails) {
            String[] roomBookingDate = eachBooking.split("//"); //split the booking info
            existingID.add(roomBookingDate[0]); //add all bookingID to arraylist
        }

        int i = existingID.size() - 1; //get index
        String lastID = existingID.get(i); //get the last id            
        int last = Integer.parseInt(lastID) + 1; //get the new id
        bookingID = Integer.toString(last); //convert to string
        return bookingID;            
    }          

    public static String[] checkBookingDetails(String bookingID) throws FileNotFoundException {

        String[] bookingDetails = CheckAllData.checkAllData("bookings.txt");            

        //create arraylist to store all booking ID
        ArrayList<String> existingList
                = new ArrayList<String>();

        //loop to get each booking from booked details arraylist
        for (String eachBooking : bookingDetails) {
            String[] roomBookingData = eachBooking.split("//"); //split the booking info
            
            //get details of one booking
            if(bookingID.equals(roomBookingData[0]))
            {
                for (String eachDetail : roomBookingData)
                {
                    existingList.add(eachDetail); //store each value in array list
                }
            }
        }
        
        // convert existing list to string array
        String[] existingDetails
                = existingList.toArray(new String[0]);
        
        return existingDetails;                
    }     

    public static Boolean checkModifyDate(String getId, String getDate, String getStartDate){
    
        Boolean modify = true; //set as true

        try { 
            String[] bookingDetails = CheckBookings.checkBookingDetails(getId);
            String previousDate = bookingDetails[7];

            //format string to date 
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            Date previous = sdf.parse(previousDate);              
            Date current = sdf.parse(getStartDate);              

            //calc 3 day b4 for previous date
            Calendar calendar = Calendar.getInstance(); //return instance with current datetime
            calendar.setTime(previous);
            calendar.add(Calendar.DAY_OF_YEAR,-3);
            Date threeDays = calendar.getTime();  
            
            //calc 3 day b4 for current selected date
            calendar.setTime(current);
            calendar.add(Calendar.DAY_OF_YEAR,-3);
            Date currentDate = calendar.getTime();

            //format date
            String threeDaysB4H = sdf.format(threeDays);
            String currDateH = sdf.format(currentDate);
            
            Date today = sdf.parse(getDate);
            Date threeDaysB4 = sdf.parse(threeDaysB4H);
            Date currDate = sdf.parse(currDateH);

            if (today.after(threeDaysB4) || today.equals(threeDaysB4)) //current date is after 3 day before or current date == 3 day before
            {
                JOptionPane.showMessageDialog(null, "Sorry, this booking cannot be modified! \nFree Cancellation is only until 3 days before Check-in", "Warning!", JOptionPane.WARNING_MESSAGE);
                modify = false;
            }
            else if (today.after(currDate) || today.equals(currDate)) //current date is after 3 day before or current date == 3 day before
            {
                JOptionPane.showMessageDialog(null, "Sorry, this booking cannot be modified! \nThe date you select must be 3 days before", "Warning!", JOptionPane.WARNING_MESSAGE);
                modify = false;
            }        

        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, ex);
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        
        return modify;
        
    }

    public static Boolean checkDeleteDate(String getId, String previousDate){
    
        Boolean modify = true; //set as true

        try { 

            //format string to date 
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            Date previous = sdf.parse(previousDate);  
            
            //get today's date
            Calendar calendar = Calendar.getInstance(); //return instance with current datetime
            String month = String.valueOf(calendar.get(Calendar.MONTH) + 1);
            String today = calendar.get(Calendar.DATE) + "-" + month + "-" + calendar.get(Calendar.YEAR);

            //calc 3 day b4 for previous date
            calendar.setTime(previous);
            calendar.add(Calendar.DAY_OF_YEAR, -3);
            Date threeDays = calendar.getTime();

            //format date
            String threeDayHandle = sdf.format(threeDays);
            Date threeDaysB4 = sdf.parse(threeDayHandle);
            Date tdy = sdf.parse(today);            

            if (tdy.after(threeDaysB4) || tdy.equals(threeDaysB4)) //current date is after 3 day before or current date == 3 day before
            {
                JOptionPane.showMessageDialog(null, "Sorry, this booking cannot be cancelled! \nFree Cancellation is only until 3 days before Check-in", "Warning!", JOptionPane.WARNING_MESSAGE);
                modify = false;
            }             

        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        
        return modify;
        
    }

    public static String[] checkSearch(String searchValue) throws FileNotFoundException{
        
        String[] bookingDetails = CheckAllData.checkAllData("bookings.txt");            

        //create arraylist to store all booking ID
        ArrayList<String> existingList
                = new ArrayList<String>();

        //loop to get each booking from booked details arraylist
        for (String eachBooking : bookingDetails) {
            String[] roomBookingData = eachBooking.split("//"); //split the booking info
            
            //avoid redundant data
            Boolean store = false;
            
            //get details of one booking
            for (String eachDetail : roomBookingData){
                
                eachDetail = eachDetail.toLowerCase().strip();
                searchValue = searchValue.toLowerCase().strip();
                
                if(eachDetail.contains(searchValue) && !store)
                {                   
                    //set true to stop adding
                    store = true; 
                    
                    //store everything
                    StringBuilder bookingBd = new StringBuilder();
                    for (int i=0; i<roomBookingData.length; i++) {

                        bookingBd.append(roomBookingData[i]);

                        //last element no need seperator
                        if (i == (roomBookingData.length - 1)){
                            break;
                        }                 
                        bookingBd.append("//");
                    }                    
                    String booking = bookingBd.toString();
                    existingList.add(booking);  
                }
                 
            }

        }
        
        // convert existing list to string array
        String[] existingDetails
                = existingList.toArray(new String[0]);

        return existingDetails;                
    }     

    public static String[] checkFuture(String[] tableDetails) throws ParseException {

        ArrayList<String> booking
                = new ArrayList<String>();

        //get today's date
        Calendar calendar = Calendar.getInstance(); //return instance with current datetime
        String month = String.valueOf(calendar.get(Calendar.MONTH) + 1);
        if (month.length() != 2) {
            month = "0" + month;
        }
        String today = calendar.get(Calendar.DATE) + "-" + month + "-" + calendar.get(Calendar.YEAR);

        //format date
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        Date tdy = sdf.parse(today);

        //loop to get each booking from table details arraylist
        for (String eachRoomBooking : tableDetails) {
            String[] roomBookingData = eachRoomBooking.split("//"); //split the booking info

            String id = roomBookingData[0];
            String start = roomBookingData[3];
            Date startDate = sdf.parse(start);//format date

            if (tdy.before(startDate)) {
                booking.add(eachRoomBooking);
            }

        }

        // convert existing list to string array
        String[] bookingDetails
                = booking.toArray(new String[0]);

        return bookingDetails;
    }

    public static String[] checkPast(String[] tableDetails) throws ParseException {

        ArrayList<String> booking
                = new ArrayList<String>();

        //get today's date
        Calendar calendar = Calendar.getInstance(); //return instance with current datetime
        String month = String.valueOf(calendar.get(Calendar.MONTH) + 1);
        if (month.length() != 2) {
            month = "0" + month;
        }
        String today = calendar.get(Calendar.DATE) + "-" + month + "-" + calendar.get(Calendar.YEAR);

        //format date
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        Date tdy = sdf.parse(today);

        //loop to get each booking from table details arraylist
        for (String eachRoomBooking : tableDetails) {
            String[] roomBookingData = eachRoomBooking.split("//"); //split the booking info

            String id = roomBookingData[0];
            String end = roomBookingData[4];
            Date endDate = sdf.parse(end);//format date

            if (tdy.after(endDate)) {
                booking.add(eachRoomBooking);
            }

        }

        // convert existing list to string array
        String[] bookingDetails
                = booking.toArray(new String[0]);

        return bookingDetails;
    }

    public static String[] checkNow(String[] tableDetails) throws ParseException {

        ArrayList<String> booking
                = new ArrayList<String>();

        //get today's date
        Calendar calendar = Calendar.getInstance(); //return instance with current datetime
        String month = String.valueOf(calendar.get(Calendar.MONTH) + 1);
        if (month.length() != 2) {
            month = "0" + month;
        }
        String today = calendar.get(Calendar.DATE) + "-" + month + "-" + calendar.get(Calendar.YEAR);

        //format date
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        Date tdy = sdf.parse(today);

        //loop to get each booking from table details arraylist
        for (String eachRoomBooking : tableDetails) {
            String[] roomBookingData = eachRoomBooking.split("//"); //split the booking info

            String id = roomBookingData[0];
            String start = roomBookingData[3];
            Date startDate = sdf.parse(start);//format date
            String end = roomBookingData[4];
            Date endDate = sdf.parse(end);//format date

            if (tdy.after(startDate) && tdy.before(endDate)) {
                booking.add(eachRoomBooking);
            } else if (tdy.equals(startDate) || tdy.equals(endDate)) {
                booking.add(eachRoomBooking);
            } 

        }

        // convert existing list to string array
        String[] bookingDetails
                = booking.toArray(new String[0]);

        return bookingDetails;
    }
    
}
