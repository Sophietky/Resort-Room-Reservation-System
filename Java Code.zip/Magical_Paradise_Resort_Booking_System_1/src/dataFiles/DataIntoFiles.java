package dataFiles;

import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
import model.BookingDetails;
import model.Staff;

public class DataIntoFiles {
    
    public static void register(Staff staff) {
        try {
            FileWriter fw = new FileWriter("staff.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.println(staff.getFullName()+"//"+staff.getUsername()+"//"+staff.getIc()+"//"+staff.getEmail()+"//"+staff.getContactNumber()+"//"+staff.getConfirmPassword());
            pw.close();
            JOptionPane.showMessageDialog(null, "Registered Successfully !","Congratulations!",JOptionPane.INFORMATION_MESSAGE);
        }catch(IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public static void bookingRegistration(BookingDetails BD) {
        try {            
            FileWriter fw = new FileWriter("bookings.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);
            pw.println(BD.getId()+"//"+BD.getFullName()+"//"+ BD.getIC()+"//"+BD.getContactNum()+"//"+BD.getEmergencyNum()+"//"+BD.getEmail()+"//"+BD.getHomeAddress()+"//"+BD.getInDate()+"//"+BD.getOutDate()+"//"+BD.getView()+"//"+BD.getRoomID()+"//"+BD.getNumOfDay()+"//"+BD.getDate()+"//"+BD.getTime()+"//"+BD.getServiceCharge()+"//"+BD.getTotalRoomPrice()+"//"+BD.getTotalAmount()+"//PENDING");
            pw.close();
            JOptionPane.showMessageDialog(null, "Booking Registered Successfully !","Congratulations!",JOptionPane.INFORMATION_MESSAGE);
        }catch(IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }        
}
