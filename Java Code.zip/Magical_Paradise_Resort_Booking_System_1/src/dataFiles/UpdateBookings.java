/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataFiles;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author sophi
 */
public class UpdateBookings 
{
    public static void updateFile(String[] modifiedBookings) {
        try {
            FileWriter fw = new FileWriter("bookings.txt", false); //write the file
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);            
            for(String eachBooking : modifiedBookings)
            {
                pw.println(eachBooking);
            }
            pw.close();
            JOptionPane.showMessageDialog(null, "Successfully Updated!","Congratulations!",JOptionPane.INFORMATION_MESSAGE);
        }catch(IOException e){
            JOptionPane.showMessageDialog(null, e);
        }
    }    
}
