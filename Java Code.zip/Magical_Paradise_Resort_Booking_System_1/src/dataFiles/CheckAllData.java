/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dataFiles;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author sophi
 */
public class CheckAllData {

    public static String[] checkAllData(String fileName) throws FileNotFoundException {
        
        // arraylist to store all data
        ArrayList<String> list
            = new ArrayList<String>();

        //open file to read
        FileInputStream fis = new FileInputStream(fileName);

        //scan file
        Scanner s = new Scanner(fis);

        // get all rows from file
        while (s.hasNextLine()) {
            list.add(s.nextLine());// adding each booking to booking LIst
        }           

        // convert booking List to string array
        String[] arrayData
            = list.toArray(new String[0]);        
                
        return arrayData;            
    }    
}
