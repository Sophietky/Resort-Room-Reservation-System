/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package magical.paradise.resort.booking.system;

import dataFiles.CheckBookings;
import javax.swing.JOptionPane;
import java.text.*;
import java.util.*;
import javax.swing.JTextField;
import dataFiles.*;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author sophi
 */
public class ModifyBooking extends javax.swing.JFrame {    

    //email format char@char.domain ((a-z0-9) + @ + (a-z0-9) + . + >=2(a-z0-9)
    public String emailValidation = "^[a-z0-9._%+-]+[@]+[a-zA-Z0-9.-]+[.]+[a-zA-Z0-9]+$";
    
    // exactly 10 number oni
    public String contactNumValidation = "^\\d{10}$";    
    
    // exactly 12 number oni
    public String icValidation = "^\\d{12}$";   
    
    public ModifyBooking() {
        initComponents();
    }

    public String bookingID;
    
    public ModifyBooking(String bookingID) throws FileNotFoundException {
        
        initComponents();     
        
        this.bookingID = bookingID;
        
        String[] bookingDetails = CheckBookings.checkBookingDetails(bookingID);
        
        idLbl.setText(bookingDetails[0]);              
        
        //set value
        txtFullName.setText(bookingDetails[1]);
        txtIC.setText(bookingDetails[2]);
        txtContactNumber.setText(bookingDetails[3]);
        txtEmergency.setText(bookingDetails[4]);
        txtEmail.setText(bookingDetails[5]);
        txtHomeAddress.setText(bookingDetails[6]);
        txtStartDate.setText(bookingDetails[7]);
        txtEndDate.setText(bookingDetails[8]);
        txtNumOfDays.setText(bookingDetails[11]);
        txtRoomID.setText(bookingDetails[10]);

        //cannot edit
        txtStartDate.setEditable(false);
        txtEndDate.setEditable(false);
        txtNumOfDays.setEditable(false);  
        txtRoomID.setEditable(false);        
        
        //set radio button
        
        if (bookingDetails[9] == "SEA")
        {
            jungleRBtn.setEnabled(false);
            seaRBtn.setSelected(true);
        }
        else
        {
            seaRBtn.setEnabled(false);
            jungleRBtn.setSelected(true);
        }
    }    

    public ModifyBooking(String bookingID, String startDate, String endDate, String numOfDay, String roomID, String view) throws FileNotFoundException {
        initComponents();
        
        String[] bookingDetails = CheckBookings.checkBookingDetails(bookingID);
        
        idLbl.setText(bookingDetails[0]);              
        
        //set value
        txtFullName.setText(bookingDetails[1]);
        txtIC.setText(bookingDetails[2]);
        txtContactNumber.setText(bookingDetails[3]);
        txtEmergency.setText(bookingDetails[4]);
        txtEmail.setText(bookingDetails[5]);
        txtHomeAddress.setText(bookingDetails[6]);
        txtStartDate.setText(startDate);
        txtEndDate.setText(endDate);
        txtNumOfDays.setText(numOfDay);
        txtRoomID.setText(roomID);

        //cannot edit
        txtStartDate.setEditable(false);
        txtEndDate.setEditable(false);
        txtNumOfDays.setEditable(false);  
        txtRoomID.setEditable(false);        
        
        //set radio button
        
        if (view == "SEA")
        {
            jungleRBtn.setEnabled(false);
            seaRBtn.setSelected(true);
        }
        else
        {
            seaRBtn.setEnabled(false);
            jungleRBtn.setSelected(true);
        }
    }   
    
    //clean the form
    public void clean(){
        txtFullName.setText("");
        txtIC.setText("");
        txtContactNumber.setText("");
        txtEmergency.setText("");
        txtEmail.setText("");
        txtHomeAddress.setText("");
        txtStartDate.setText("");
        txtEndDate.setText("");
        txtNumOfDays.setText("");
        txtRoomID.setText("");           
    }
    
    public Boolean BookingDetailsValidation(String getFullName, String getIc, String getEmail, String getContactNumber, String getEmergencyNumber, String getHomeAddress) {
        Boolean valid = false;
        
        try
            {        
            if(getFullName.equals("") || getIc.equals("") || getEmail.equals("") || getContactNumber.equals("")  || getEmergencyNumber.equals("")  || getHomeAddress.equals("")){
                JOptionPane.showMessageDialog(this, "Please fill up all the details to register","Warning!",JOptionPane.WARNING_MESSAGE);
            }
            else if(!getIc.matches(icValidation))
            {
                JOptionPane.showMessageDialog(this, "Your IC / Passport number should be exactly 12 numbers.\nPlease enter again.","Warning!",JOptionPane.WARNING_MESSAGE);            
            }
            else if (!getEmail.matches(emailValidation))
            {
                JOptionPane.showMessageDialog(this, "Your email is invalid.\nPlease enter again.","Warning!",JOptionPane.WARNING_MESSAGE);
            }
            else if (!getContactNumber.matches(contactNumValidation))
            {
                JOptionPane.showMessageDialog(this, "Your contact number is invalid.\nPlease enter again.","Warning!",JOptionPane.WARNING_MESSAGE);
            }  
            else if (!getEmergencyNumber.matches(contactNumValidation))
            {
                JOptionPane.showMessageDialog(this, "Your emergency contact number is invalid.\nPlease enter again.","Warning!",JOptionPane.WARNING_MESSAGE);
            }   
            else             
            {
                valid = true;
                clean();
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }        
        
        return valid;            
    }    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        viewBtnGrp = new javax.swing.ButtonGroup();
        registerLbl = new javax.swing.JLabel();
        logoutBtn = new javax.swing.JButton();
        closeBtn = new javax.swing.JButton();
        fillUpLbl = new javax.swing.JLabel();
        backBtn = new javax.swing.JButton();
        fullNameLbl = new javax.swing.JLabel();
        txtFullName = new javax.swing.JTextField();
        txtIC = new javax.swing.JTextField();
        icLbl = new javax.swing.JLabel();
        txtContactNumber = new javax.swing.JTextField();
        contactLbl = new javax.swing.JLabel();
        txtEmergency = new javax.swing.JTextField();
        emergencyLbl = new javax.swing.JLabel();
        txtHomeAddress = new javax.swing.JTextField();
        homeAddressLbl = new javax.swing.JLabel();
        emailLbl = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        startDateLbl = new javax.swing.JLabel();
        txtStartDate = new javax.swing.JTextField();
        txtEndDate = new javax.swing.JTextField();
        endDateLbl = new javax.swing.JLabel();
        viewLbl = new javax.swing.JLabel();
        roomIDLbl = new javax.swing.JLabel();
        jungleRBtn = new javax.swing.JRadioButton();
        seaRBtn = new javax.swing.JRadioButton();
        resetBtn = new javax.swing.JButton();
        confirmBtn = new javax.swing.JButton();
        txtRoomID = new javax.swing.JTextField();
        bookingNumLbl = new javax.swing.JLabel();
        idLbl = new javax.swing.JLabel();
        modifyBtn = new javax.swing.JButton();
        numOfDayLbl = new javax.swing.JLabel();
        txtNumOfDays = new javax.swing.JTextField();
        backgroundLbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(1200, 720));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        registerLbl.setFont(new java.awt.Font("Roboto", 1, 24)); // NOI18N
        registerLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        registerLbl.setText("Modify Booking !");
        getContentPane().add(registerLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 1000, -1));

        logoutBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/logout.png"))); // NOI18N
        logoutBtn.setBorderPainted(false);
        logoutBtn.setContentAreaFilled(false);
        logoutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutBtnActionPerformed(evt);
            }
        });
        getContentPane().add(logoutBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 30, -1));

        closeBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/close.png"))); // NOI18N
        closeBtn.setBorderPainted(false);
        closeBtn.setContentAreaFilled(false);
        closeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeBtnActionPerformed(evt);
            }
        });
        getContentPane().add(closeBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 50, 40, -1));

        fillUpLbl.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        fillUpLbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        fillUpLbl.setText("Please Modify Room Details First");
        getContentPane().add(fillUpLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 90, 230, 20));

        backBtn.setBackground(new java.awt.Color(0, 0, 0));
        backBtn.setForeground(new java.awt.Color(255, 255, 255));
        backBtn.setText("Back");
        backBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnActionPerformed(evt);
            }
        });
        getContentPane().add(backBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 630, 170, 55));

        fullNameLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        fullNameLbl.setText("Full Name");
        getContentPane().add(fullNameLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, 430, -1));
        getContentPane().add(txtFullName, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 150, 430, 40));
        getContentPane().add(txtIC, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 230, 430, 40));

        icLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        icLbl.setText("I.C.  No. / Passport No. (Only Numbers)");
        getContentPane().add(icLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 210, 430, -1));
        getContentPane().add(txtContactNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 310, 430, 40));

        contactLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        contactLbl.setText("Contact Number (Only Numbers)");
        getContentPane().add(contactLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 290, 430, -1));
        getContentPane().add(txtEmergency, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 390, 430, 40));

        emergencyLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        emergencyLbl.setText("Emergency Contact Number (Only Numbers)");
        getContentPane().add(emergencyLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 370, 430, -1));
        getContentPane().add(txtHomeAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 550, 430, 40));

        homeAddressLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        homeAddressLbl.setText("Home Address");
        getContentPane().add(homeAddressLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 530, 430, -1));

        emailLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        emailLbl.setText("Email Address");
        getContentPane().add(emailLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 450, 430, -1));
        getContentPane().add(txtEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 470, 430, 40));

        startDateLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        startDateLbl.setText("Start Date");
        getContentPane().add(startDateLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 210, 430, -1));
        getContentPane().add(txtStartDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 230, 430, 40));
        getContentPane().add(txtEndDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 310, 430, 40));

        endDateLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        endDateLbl.setText("End Date");
        getContentPane().add(endDateLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 290, 430, -1));

        viewLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        viewLbl.setText("View");
        getContentPane().add(viewLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 450, 430, -1));

        roomIDLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        roomIDLbl.setText("Room ID");
        getContentPane().add(roomIDLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 530, 430, -1));

        viewBtnGrp.add(jungleRBtn);
        jungleRBtn.setText("Jungle View");
        jungleRBtn.setActionCommand("JUN");
        getContentPane().add(jungleRBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 480, -1, -1));

        viewBtnGrp.add(seaRBtn);
        seaRBtn.setText("Sea View");
        seaRBtn.setActionCommand("SEA");
        getContentPane().add(seaRBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 480, -1, -1));

        resetBtn.setBackground(new java.awt.Color(0, 0, 0));
        resetBtn.setForeground(new java.awt.Color(255, 255, 255));
        resetBtn.setText("Reset");
        resetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBtnActionPerformed(evt);
            }
        });
        getContentPane().add(resetBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 630, 170, 55));

        confirmBtn.setBackground(new java.awt.Color(0, 0, 0));
        confirmBtn.setForeground(new java.awt.Color(255, 255, 255));
        confirmBtn.setText("Confirm");
        confirmBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmBtnActionPerformed(evt);
            }
        });
        getContentPane().add(confirmBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 630, 170, 55));
        getContentPane().add(txtRoomID, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 550, 430, 40));

        bookingNumLbl.setBackground(new java.awt.Color(0, 0, 0));
        bookingNumLbl.setFont(new java.awt.Font("Poor Richard", 1, 18)); // NOI18N
        bookingNumLbl.setForeground(new java.awt.Color(255, 0, 51));
        bookingNumLbl.setText("BOOKING NUMBER:");
        getContentPane().add(bookingNumLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 150, -1, -1));

        idLbl.setBackground(new java.awt.Color(0, 0, 0));
        idLbl.setFont(new java.awt.Font("Poor Richard", 1, 18)); // NOI18N
        idLbl.setForeground(new java.awt.Color(255, 0, 51));
        idLbl.setText("X");
        getContentPane().add(idLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 150, 50, -1));

        modifyBtn.setBackground(new java.awt.Color(0, 0, 0));
        modifyBtn.setForeground(new java.awt.Color(255, 255, 255));
        modifyBtn.setText("Modify Room Details");
        modifyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifyBtnActionPerformed(evt);
            }
        });
        getContentPane().add(modifyBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 130, 170, 55));

        numOfDayLbl.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        numOfDayLbl.setText("Number Of Days");
        getContentPane().add(numOfDayLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 370, 430, -1));
        getContentPane().add(txtNumOfDays, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 390, 430, 40));

        backgroundLbl.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/white bg.png"))); // NOI18N
        getContentPane().add(backgroundLbl, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1200, 720));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void logoutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutBtnActionPerformed
        // TODO add your handling code here:
        int confirmLogout = JOptionPane.showConfirmDialog(null, "Do you really want to Logout?", "Please Select", JOptionPane.YES_NO_OPTION);
        if (confirmLogout == 0) {
            setVisible(false);
            new Welcome().setVisible(true);
        }
    }//GEN-LAST:event_logoutBtnActionPerformed

    private void closeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeBtnActionPerformed
        // TODO add your handling code here:
        int confirmClose = JOptionPane.showConfirmDialog(null, "Do you really want to Close Magical Paradise Resort Booking System ?", "Please Select", JOptionPane.YES_NO_OPTION);
        if (confirmClose == 0) {
            System.exit(0);
        }        
    }//GEN-LAST:event_closeBtnActionPerformed

    private void backBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtnActionPerformed
        setVisible(false);
    }//GEN-LAST:event_backBtnActionPerformed

    private void resetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBtnActionPerformed
        clean();
    }//GEN-LAST:event_resetBtnActionPerformed

    private void confirmBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmBtnActionPerformed
                                   
        //get value from text field
        String getId = idLbl.getText();
        String getFullName = txtFullName.getText();
        String getIc = txtIC.getText();
        String getContactNumber = txtContactNumber.getText();
        String getEmergencyNumber = txtEmergency.getText();
        String getEmail = txtEmail.getText();
        String getHomeAddress = txtHomeAddress.getText();
        String getStartDate = txtStartDate.getText();
        String getEndDate = txtEndDate.getText();
        String getNumOfDays = txtNumOfDays.getText();
        String getRoomID = txtRoomID.getText();
        
        //get date time
        Calendar calendar = Calendar.getInstance(); //return instance with current datetime
        String month = String.valueOf(calendar.get(Calendar.MONTH) + 1);  
        String getDate = calendar.get(Calendar.DATE)+"-"+month+"-"+calendar.get(Calendar.YEAR);
        String getTime = calendar.get(Calendar.HOUR)+":"+calendar.get(Calendar.MINUTE)+":"+calendar.get(Calendar.SECOND);
        
        //get radio button value
        String getView = viewBtnGrp.getSelection().getActionCommand();
        
        //check todays date is it 3 days b4
        Boolean canModify = CheckBookings.checkModifyDate(getId, getDate, getStartDate);
        
        if (canModify)
        {
            Boolean valid = BookingDetailsValidation(getFullName, getIc,getEmail, getContactNumber, getEmergencyNumber, getHomeAddress);
            
            if(valid)
            {
                //calculate total & service charge
                double dTotalRoomPrice = 350 * Integer.parseInt(getNumOfDays);
                double dServiceCharge = dTotalRoomPrice * 0.1;
                double dTotalAmount = dTotalRoomPrice + dServiceCharge + 10;
                
                //2 decimal place
                NumberFormat nf= NumberFormat.getInstance();
                nf.setMaximumFractionDigits(2);
                
                //convert to string with 2 decimal
                String getTotalRoomPrice = nf.format(dTotalRoomPrice);
                String getServiceCharge = nf.format(dServiceCharge);
                String getTotalAmount = nf.format(dTotalAmount);                
                
                try {
                    //modify
                    String[] modifiedBookings = EditBookings.updateBookings(getId, getContactNumber, getEmail, getEmergencyNumber, getFullName, getHomeAddress, getIc, 
                            getStartDate, getNumOfDays, getEndDate, getRoomID, getView, getDate, getTime, getTotalAmount,getServiceCharge, getTotalRoomPrice);
                    
                    //store modify list
                    UpdateBookings.updateFile(modifiedBookings);
                    setVisible(false);
                    new BookedSuccessfully(getId,"close").setVisible(true);
                    
                } catch (FileNotFoundException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                }
            }
        }
    }//GEN-LAST:event_confirmBtnActionPerformed

    private void modifyBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifyBtnActionPerformed
        setVisible(false);
        new BookARoom(idLbl.getText()).setVisible(true);
    }//GEN-LAST:event_modifyBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ModifyBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ModifyBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ModifyBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ModifyBooking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ModifyBooking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBtn;
    private javax.swing.JLabel backgroundLbl;
    private javax.swing.JLabel bookingNumLbl;
    private javax.swing.JButton closeBtn;
    private javax.swing.JButton confirmBtn;
    private javax.swing.JLabel contactLbl;
    private javax.swing.JLabel emailLbl;
    private javax.swing.JLabel emergencyLbl;
    private javax.swing.JLabel endDateLbl;
    private javax.swing.JLabel fillUpLbl;
    private javax.swing.JLabel fullNameLbl;
    private javax.swing.JLabel homeAddressLbl;
    private javax.swing.JLabel icLbl;
    private javax.swing.JLabel idLbl;
    private javax.swing.JRadioButton jungleRBtn;
    private javax.swing.JButton logoutBtn;
    private javax.swing.JButton modifyBtn;
    private javax.swing.JLabel numOfDayLbl;
    private javax.swing.JLabel registerLbl;
    private javax.swing.JButton resetBtn;
    private javax.swing.JLabel roomIDLbl;
    private javax.swing.JRadioButton seaRBtn;
    private javax.swing.JLabel startDateLbl;
    private javax.swing.JTextField txtContactNumber;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEmergency;
    private javax.swing.JTextField txtEndDate;
    private javax.swing.JTextField txtFullName;
    private javax.swing.JTextField txtHomeAddress;
    private javax.swing.JTextField txtIC;
    private javax.swing.JTextField txtNumOfDays;
    private javax.swing.JTextField txtRoomID;
    private javax.swing.JTextField txtStartDate;
    private javax.swing.ButtonGroup viewBtnGrp;
    private javax.swing.JLabel viewLbl;
    // End of variables declaration//GEN-END:variables
}
